<?php 
//echo get_template_directory_uri();
?>

<img src="<?php echo get_template_directory_uri() . "/images/404.jpg"; ?>">