<?php get_header(); ?>
Index.php
<h1>Demo Theme</h1>

<?php get_footer(); ?>