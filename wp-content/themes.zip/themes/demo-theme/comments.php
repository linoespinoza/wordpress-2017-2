<h3>Formulario de comentarios</h3>

<form>
	<label for="nombre">Nombre</label>
	<input type="text" name="nombre"> <br>

	<label for="email">Email</label>
	<input type="text" name="email"> <br>

	<input type="submit" value="Enviar">
</form>