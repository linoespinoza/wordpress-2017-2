	<hr>
    
    <div class="container">
      <footer>
        
        <p>Demo site for learning the WordPress template hierarchy</p>
      	
      </footer>
    </div> <!-- /container -->

    <?php wp_footer(); ?>
    
  </body>
</html>
